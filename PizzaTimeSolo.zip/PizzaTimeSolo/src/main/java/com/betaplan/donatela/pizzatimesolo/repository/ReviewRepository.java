package com.betaplan.donatela.pizzatimesolo.repository;

import com.betaplan.donatela.pizzatimesolo.models.Pizza;

import com.betaplan.donatela.pizzatimesolo.models.Review;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface ReviewRepository extends CrudRepository<Review, Long>{


	List<Review> findByPizza(Pizza pizza);
	//Delete a review


}
