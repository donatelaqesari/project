package com.betaplan.donatela.pizzatimesolo.service;


import com.betaplan.donatela.pizzatimesolo.models.Pizza;
import com.betaplan.donatela.pizzatimesolo.models.Review;
import com.betaplan.donatela.pizzatimesolo.models.User;
import com.betaplan.donatela.pizzatimesolo.repository.PizzaRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PizzaService {
	private final PizzaRepository PizzaRepository;

	public PizzaService(PizzaRepository PizzaRepository) {
		this.PizzaRepository = PizzaRepository;
	}
	
	public List<Pizza> findAllPizzas() {
    	return PizzaRepository.findAll();
	}
	
	public List<Pizza> findPizzaByUser(User user){
		return PizzaRepository.findByUser(user);
	}
	
	public List<Pizza> findByAddress(String search) {
       	return  PizzaRepository.findByAddressContaining(search);
    }
	
	public Pizza createPizza(Pizza b) {
		return  PizzaRepository.save(b);
	    }
	
	public Pizza findPizza(Long id) {
	    Optional<Pizza> optionalPizza =  PizzaRepository.findById(id);
	    return optionalPizza.isPresent()?  optionalPizza.get() : null;
	}
	
	public Pizza updatePizza(Long id, Pizza Pizza) {
		Pizza current_Pizza = findPizza(id);
		current_Pizza.setAddress(Pizza.getAddress());
		current_Pizza.setDescription(Pizza.getDescription());
		current_Pizza.setCost(Pizza.getCost());
		current_Pizza.setPizzaSize(Pizza.getPizzaSize());
		return  PizzaRepository.save(current_Pizza);
	    }
	
	public Pizza updateRating (Pizza Pizza) {
		Double rating = 0.0;
		for (Review review :Pizza.getReviews()) {
			rating+=review.getRating();
		}
		rating=rating/Pizza.getReviews().size();
		Pizza.setRating(rating);
		return PizzaRepository.save(Pizza);
	}

}
