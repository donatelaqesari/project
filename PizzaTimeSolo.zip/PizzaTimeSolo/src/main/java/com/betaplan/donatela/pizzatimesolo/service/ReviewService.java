package com.betaplan.donatela.pizzatimesolo.service;

import com.betaplan.donatela.pizzatimesolo.models.Review;
import com.betaplan.donatela.pizzatimesolo.repository.ReviewRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ReviewService {
	private final ReviewRepository reviewRepository;

	public ReviewService(ReviewRepository reviewRepository) {
		this.reviewRepository = reviewRepository;
	}
	
	
	public Review createReview(Review b) {
		return  reviewRepository.save(b);
	    }
	
	public Review findReview(Long id) {
	    Optional<Review> optionalReview =  reviewRepository.findById(id);
	    return optionalReview.isPresent()?  optionalReview.get() : null;
	}
	public void delete(Long id) {
		this.reviewRepository.deleteById(id);
	}

}
