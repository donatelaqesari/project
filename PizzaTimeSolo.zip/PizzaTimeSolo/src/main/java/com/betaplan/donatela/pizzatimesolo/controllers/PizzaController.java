package com.betaplan.donatela.pizzatimesolo.controllers;

import com.betaplan.donatela.pizzatimesolo.models.Pizza;
import com.betaplan.donatela.pizzatimesolo.models.Review;
import com.betaplan.donatela.pizzatimesolo.models.User;
import com.betaplan.donatela.pizzatimesolo.service.PizzaService;
import com.betaplan.donatela.pizzatimesolo.service.ReviewService;
import com.betaplan.donatela.pizzatimesolo.service.UserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;
import java.util.Comparator;
import java.util.List;



@Controller
public class PizzaController {
	private final PizzaService PizzaService;
	private final UserService userService;
	private final ReviewService reviewService;

	public PizzaController(PizzaService PizzaService, UserService userService, ReviewService reviewService) {
		this.PizzaService = PizzaService;
		this.userService = userService;
		this.reviewService = reviewService;
	}


	//home page 
	@GetMapping("/")
	public String home(Model model,HttpSession session, RedirectAttributes redirectAttributes) { 
		return "/index.jsp";
	}
	
	// search by artist name
	@GetMapping(value="/search")
	public String search(
		@RequestParam(value = "search") String search ,
		Model model,
		RedirectAttributes redirectAttributes) {	
		if (search.isEmpty()) {
			return "redirect:/";
		}
		List<Pizza> pizzas = PizzaService.findByAddress(search);
		if (pizzas.isEmpty()) {
			redirectAttributes.addFlashAttribute("error", "Location "+search+" is not found");
			return "redirect:/";
		}
        return "redirect:/search/"+search;
	}
	
	// show the results of the search 
	@GetMapping(value="/search/{search}")
	public String dsplaySearch(@PathVariable(value = "search") String search , Model model ) {
		List<Pizza> pizzas = PizzaService.findByAddress(search);
		model.addAttribute("pizzas",pizzas);
		model.addAttribute("location",search);
        return "/search-result.jsp";
    }


	//Display all of the pizzas from the database
	@GetMapping("/pizzas/all")
	public String allPizzas(Model model, @ModelAttribute("pizza") Pizza pizza, HttpSession session) {
		if (session.getAttribute("user_id") != null) {
			User currentUser = userService.findUser((Long)session.getAttribute("user_id"));
			model.addAttribute("currentUser", currentUser);
		}

		List<Pizza> pizzas = PizzaService.findAllPizzas();

		pizzas.sort(Comparator.comparing(Pizza::getAddress));

		model.addAttribute("pizzas", pizzas);
		return "allPizzas.jsp";
	}
	
	@GetMapping(value="/host/dashboard")
	public String add(Model model,
			RedirectAttributes redirectAttributes,
			HttpSession session) {
		if (! session.getAttribute("role").equals("Host")) {
			redirectAttributes.addFlashAttribute("error", "only Host can access this page");
			return "redirect:/";
		}
		if (!model.containsAttribute("pizza")) {
			model.addAttribute("pizza",new Pizza());
		}
		User user = userService.findUser((long) session.getAttribute("user_id"));
		List<Pizza> pizzas = PizzaService.findPizzaByUser(user);
		model.addAttribute("pizzas",pizzas);
		return "/dashboard.jsp";
	}
		
	// add new Pizza
	@PostMapping(value="/host/dashboard")
	public String add(Model model, @Valid @ModelAttribute("pizza") Pizza pizza,
			BindingResult result, 
			RedirectAttributes redirectAttributes,
			HttpSession session
			) {
		if (result.hasErrors()) {
			redirectAttributes.addFlashAttribute("pizza",pizza);
			redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.Pizza",result);
			return "redirect:/host/dashboard";
        } 
		
		Long id= (Long) session.getAttribute("user_id");
		User user = userService.findUser(id);
		pizza.setUser(user);
		PizzaService.createPizza(pizza);
    	redirectAttributes.addFlashAttribute("success", "Pizza was created successfully");
        return "redirect:/host/dashboard";
	        
		}

	
	
	
		// show the edit form page 
		@GetMapping("/pizzas/{id}")
		public String edit(@PathVariable("id") Long id, Model model,RedirectAttributes redirectAttributes
				,HttpSession session) {
			if (session.getAttribute("user_id")== null) {
				redirectAttributes.addFlashAttribute("error", "register/login to access this page");
				return "redirect:/";
			}
			if (!model.containsAttribute("pizza")) {
				Pizza pizza = PizzaService.findPizza(id);
				model.addAttribute("pizza", pizza);
			}
			
			model.addAttribute("pizzaid", id);
		    return "/show_pizza.jsp";
		}
		    
		// edit 
		@PutMapping(value="/pizzas/{id}/edit")
		public String update(@PathVariable("id") Long id,@Valid @ModelAttribute("pizza") Pizza pizza ,
				BindingResult result, 
				RedirectAttributes redirectAttributes, 
				HttpSession session) {
			if (result.hasErrors()) {
				redirectAttributes.addFlashAttribute("pizza",pizza);
				redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.Pizza",result);
				return "redirect:/pizzas/"+id;
			}

			Long user_id= (Long) session.getAttribute("user_id");
			User user = userService.findUser(user_id);
			pizza.setUser(user);
			PizzaService.updatePizza(id,pizza);
			redirectAttributes.addFlashAttribute("success", "Pizza was edited successfully");
			return "redirect:/host/dashboard";
			}
		
		// show review form page
		@GetMapping("/pizzas/{id}/review")
		public String showReview(@PathVariable("id") Long id, Model model,
				RedirectAttributes redirectAttributes,
				HttpSession session) {
			if (session.getAttribute("user_id")== null) {
				redirectAttributes.addFlashAttribute("error", "register/login to access this page");
				return "redirect:/";
			}
			if (!model.containsAttribute("review")) {
				Review review = new Review();
				model.addAttribute("review", review);
			}
			Pizza pizza = PizzaService.findPizza(id);
			model.addAttribute("pizza", pizza);
			model.addAttribute("pizzaid", id);
		    return "/add_review.jsp";
		}
		
		// add a new review to Pizza 
		@PostMapping("/pizzas/{id}/review/add")
		public String addReview (@PathVariable("id") Long id,@Valid @ModelAttribute("review") Review review ,
				BindingResult result, 
				RedirectAttributes redirectAttributes, 
				HttpSession session) {
			if (result.hasErrors()) {
				redirectAttributes.addFlashAttribute("review",review);
				redirectAttributes.addFlashAttribute("org.springframework.validation.BindingResult.review",result);
				return "redirect:/pizzas/"+id+"/review";
			}
			
			Long user_id= (Long) session.getAttribute("user_id");
			User user = userService.findUser(user_id);
			
			Pizza pizza = PizzaService.findPizza(id);
			
			// create review after assigning user and Pizza
			review.setUser(user);
			review.setPizza(pizza);
			reviewService.createReview(review);
			
			// update Pizza rating 
			PizzaService.updateRating(pizza);
			redirectAttributes.addFlashAttribute("success", "Review was edited successfully");
			return "redirect:/pizzas/"+id;
		}
	 @GetMapping("/pizzas/{id}/delete")
	public String delete(Model model, @PathVariable("id") Long id, HttpSession session) {
		Review review = reviewService.findReview(id);
		model.addAttribute("review", review);

		if (session.getAttribute("user_id") != null && session.getAttribute("user_id") == review.getUser().getId()) {

			User currentUser = userService.findUser((Long) session.getAttribute("user_id"));
			model.addAttribute("currentUser", currentUser);
			Long userId = currentUser.getId();

			this.reviewService.delete(id);
			return "redirect:/pizzas/"+userId;

		}

		return "/show_pizza.jsp";

	}
}
