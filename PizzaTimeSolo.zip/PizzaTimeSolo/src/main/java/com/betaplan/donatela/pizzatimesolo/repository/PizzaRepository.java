package com.betaplan.donatela.pizzatimesolo.repository;


import com.betaplan.donatela.pizzatimesolo.models.Pizza;
import com.betaplan.donatela.pizzatimesolo.models.User;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PizzaRepository extends CrudRepository<Pizza, Long>{
	List<Pizza> findByAddressContaining(String search);
	
	List<Pizza> findAll();
	
	List<Pizza> findByUser(User user);
}
